<?php $__env->startSection('myContent'); ?>

<!-- banner -->
<div class="page-head">
	<div class="container">
		<h3>Payment</h3>
	</div>
</div>
<!-- //banner -->
<!-- check out -->
<div class="checkout">
	<div class="container">
		<h3>Payment From</h3>

			<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
		<?php endif; ?>
			<?php if(session('error')): ?>
    <div class="alert alert-success">
        <?php echo e(session('error')); ?>

    </div>
		<?php endif; ?>
	<form class="" action="<?php echo e(url('/checkout/payment/save')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="cash">
        <input type="radio" class="form-check-input" name="payment_type" value="cash" id="cash" name="optradio" checked style="margin-right : 20px;">Cash On Delivery
      </label>
    </div>
    <div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="bkash">
        <input type="radio" class="form-check-input" name="payment_type" value="bkash" id="bkash" name="optradio" style="margin-right : 20px;">Bkash
      </label>
    </div>
    <div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="Paypal">
        <input type="radio" class="form-check-input" name="payment_type" value="paypal" id="Paypal" style="margin-right : 20px;">Paypal
      </label>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>

	</form>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>