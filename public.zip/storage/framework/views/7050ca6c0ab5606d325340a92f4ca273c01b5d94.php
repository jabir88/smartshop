<?php $__env->startSection('myContent'); ?>

<div id="page-wrapper">
    <div class="row">
      <div class="col-12">
         <?php echo Form::open(['url' =>'admin/manufacturer/save', 'method' => 'post', 'class'=> 'form-group']); ?>

         <?php echo csrf_field(); ?>
         <?php if(session('status')): ?>
   <div class="alert alert-success">
       <?php echo e(session('status')); ?>

   </div>
<?php endif; ?>
          <div class="form-group">
            <label  style="display: block; color:#3895D3; font-weight:700;" for="manu_name">Manufacturer Name</label>
            <input type="text" name="manu_name"  class="form-control" id="manu_name" value="<?php echo e(old('manu_name')); ?>"  placeholder="Manufacturer Name">

          <?php if($errors->has('manu_name')): ?>
              <span class="invalid-feedback" role="alert">
                  <strong><?php echo e($errors->first('manu_name')); ?></strong>
              </span>
          <?php endif; ?>
        </div>
          <div class="form-group">
            <label  style="display: block; color:#3895D3; font-weight:700;" for="manu_des">Manufacturer Description</label>
            <textarea name="manu_des" id="manu_des" placeholder="Manufacturer Description...."  rows="5" cols="128"> <?php echo e(old('manu_des')); ?></textarea>
            <?php if($errors->has('manu_des')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('manu_des')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <div class="form-group">
            <label  style="display: block; color:#3895D3; font-weight:700;" >Publication Status</label>
            <select class="form-control" value="<?php echo e(old('pub_status')); ?>" name="pub_status">
              <option selected>Select Publication</option>
              <option value="1">Published</option>
              <option value="0">Unpublished</option>
            </select>
            <?php if($errors->has('pub_status')): ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($errors->first('pub_status')); ?></strong>
                </span>
            <?php endif; ?>
          </div>
          <button type="submit" style="background:#3895D3;border:#3895D3;" class="btn btn-primary">Submit</button>
           <?php echo Form::close(); ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>