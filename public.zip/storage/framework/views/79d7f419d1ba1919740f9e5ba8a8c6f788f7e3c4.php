<?php $__env->startSection('myContent'); ?>
      <div id="page-wrapper">
<div class="row">
  <div class="col-lg-10">
    <div class="panel-body">

                            <div class="table-responsive">
                                <h4> Total Users = <?php echo e($alluser->total()); ?></h4>
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>S/N</th>
                                            <th>First Name</th>
                                            <th>E-mail</th>
                                            <th>Address</th>
                                            <th>Role</th>
                                            <th>Time</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i=1 ?>
                                        <?php $__currentLoopData = $alluser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td> <?php echo e($i); ?></td>
                                            <td><?php echo e($data['name']); ?></td>
                                            <td><?php echo e($data['email']); ?></td>
                                            <td><?php echo e($data['address']); ?></td>
                                            <td><?php echo e($data-> RoleName->role_name); ?></td>
                                            <!-- <td><?php echo e($data['created_at']); ?></td> -->
                                            <?php $m = $data['created_at']; ?>
                                            <!-- <td><?php echo e($m); ?></td> -->
                                            <td><?php echo e(\Carbon\Carbon::parse($m)->diffForHumans()); ?></td>
                                            <!-- <td><?php echo e(\Carbon\Carbon::now()->diffForHumans($m)); ?></td> -->



                                            <?php $i++;?>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <?php echo e($alluser->links()); ?>

  </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>