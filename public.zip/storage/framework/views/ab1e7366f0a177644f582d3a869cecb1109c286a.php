<?php $__env->startSection('myContent'); ?>

<div id="page-wrapper">
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8 card_header_text">
                        <i class="fa fa-th"></i> Manage Manufacturer
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(url('admin/manufacturer/add')); ?>" class="btn btn-dark btn-sm card_button"><i class="fa fa-plus-circle"></i> Add Manufacturer</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="allTable" class="table table-bordered table-striped table-hover customize_table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Manufacturer Name</th>
                                <th>Manufacturer  Description</th>
                                <th>Publication Status</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $i=1;?>
                          <?php $__currentLoopData = $manu_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>

                              <td><?php echo e($i); ?>  </td>
                              <td><?php echo e($data->manu_name); ?></td>
                              <td><?php echo e(str_limit($data->manu_des, 30)); ?></td>
                              <td><?php echo e($data->pub_status == 1 ? 'Published' :'Unpublished'); ?></td>
                              <td>
                                <a href="<?php echo e(url('admin/manufacturer/singleview/'.$data->manu_id)); ?>"><i class="fa fa-plus-square"></i></a>
                                <a href="<?php echo e(url('admin/manufacturer/edit/'.$data->manu_id)); ?>"><i class="fa fa-pencil-square"></i></a>
                                <a href="<?php echo e(url('admin/manufacturer/delete/'.$data->manu_id)); ?>"><i class="fa fa-trash"></i></a>
                              </td>
                            </tr>

                                                            <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-info btn-sm">Print</a>
            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>