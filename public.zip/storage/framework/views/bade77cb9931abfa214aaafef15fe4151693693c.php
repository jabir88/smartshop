<?php $__env->startSection('myContent'); ?>

<div id="page-wrapper">
    <div class="row">
      <div class="col-12">
        <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-md-8 card_header_text">
                        <i class="fa fa-th"></i> All Orders
                    </div>
                    <div class="col-md-4 text-right">
                        <a href="<?php echo e(url('admin/manufacturer/add')); ?>" class="btn btn-dark btn-sm card_button"><i class="fa fa-plus-circle"></i> Add Manufacturer</a>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table id="allTable" class="table table-bordered table-striped table-hover customize_table">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Customer Name</th>
                                <th>Order Total</th>
                                <th>Order Status</th>
                                <th>Manage</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $i=1;?>
                          <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>

                              <td><?php echo e($i); ?>  </td>
                              <td><?php echo e($data->customer_firstname); ?></td>
                              <td><?php echo e(number_format($data->order_total)); ?></td>
                              <td>
                                <?php if($data->order_status == 'pending'): ?>
                                <button type="button" class="btn btn-warning btn-xs">Pending</button>
                                <?php else: ?>
                                <button type="button" class="btn btn-success btn-xs">Success</button>

                                <?php endif; ?>
                              </td>
                              <td>
                                <a href="<?php echo e(url('admin/order/done/'.$data->order_id)); ?>"><i class="fa fa-pencil-square"></i></a>
                                <a href="<?php echo e(url('admin/order/view/'.$data->order_id)); ?>"><i class="fa fa-plus-square"></i></a>
                                <a href="<?php echo e(url('admin/order/delete/'.$data->order_id)); ?>"><i class="fa fa-trash"></i></a>
                              </td>
                            </tr>

                                                            <?php $i++; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="card-footer">
                <a href="#" class="btn btn-info btn-sm">Print</a>
            </div>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>