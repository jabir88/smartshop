<?php $__env->startSection('myContent'); ?>

<div id="page-wrapper">
    <div class="row">
      <div class="col-md-6 ">
                <div class=" panel panel-default" style="margin : 50px 0 0 0">
                    <div class="panel-heading">
                        <h3 class="panel-title">Change Password</h3>
                    </div>
                    <?php if(session('status')): ?>
                      <div class="alert alert-success">
                          <?php echo e(session('status')); ?>

                      </div>
                  <?php endif; ?>
                    <?php if(session('error')): ?>
                      <div class="alert alert-danger">
                          <?php echo e(session('error')); ?>

                      </div>
                  <?php endif; ?>
                    <div class="panel-body">
                      <?php echo e(Form::open(['route' => 'password.change.submit', 'method' => 'post'])); ?>


                            <fieldset>
                                <div class="form-group">
                                  <?php echo e(Form::label('old_pass', 'Old Password')); ?>

                                    <?php echo e(Form::password('old_pass', ['class' => 'form-control' ,'placeholder' => 'Old Password'])); ?>

                                    <?php if($errors->has('old_pass')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('old_pass')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                  <?php echo e(Form::label('new_pass', 'New Password')); ?>

                                  <?php echo e(Form::password('new_pass', ['class' => 'form-control' ,'placeholder' => 'New Password'])); ?>

                                  <?php if($errors->has('new_pass')): ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($errors->first('new_pass')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                                </div>
                                <div class="form-group">
                                  <?php echo e(Form::label('retype_pass', 'Re-type Password')); ?>

                                  <?php echo e(Form::password('retype_pass', ['class' => 'form-control' ,'placeholder' => 'Re-type Password'])); ?>

                                  <?php if($errors->has('retype_pass')): ?>
                                      <span class="invalid-feedback" role="alert">
                                          <strong><?php echo e($errors->first('retype_pass')); ?></strong>
                                      </span>
                                  <?php endif; ?>
                                </div>
                          <?php echo e(Form::submit('Change Password' , ['class'=>'btn btn-lg btn-success btn-block'])); ?>

                                <!-- Change this to a button or input when using this as a form -->

                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.adminmaster', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>