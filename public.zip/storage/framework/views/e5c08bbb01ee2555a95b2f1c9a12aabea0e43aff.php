<?php $__env->startSection('myContent'); ?>

<!-- banner -->
<div class="page-head">
	<div class="container">
		<h3>Payment</h3>
	</div>
</div>
<!-- //banner -->
<!-- check out -->

<div class="checkout">
	<div class="container">
		<h3>My Shopping Bag</h3>
		<div class="table-responsive checkout-right animated wow slideInUp" data-wow-delay=".5s">
			<?php $contents = Cart::content();

			?>
			<table class="timetable_sub">
				<thead>
					<tr>

						<th>Product</th>
						<th>Product Name</th>
						<th>Price</th>
						<th>Quantity</th>
						<th>Total Price</th>
						<th>Remove</th>
					</tr>
				</thead>
					<?php $__currentLoopData = $contents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="rem1">

						</td>
						<td class="invert-image"><a href="<?php echo e(url('/single/'.$content->id)); ?>"><img src="<?php echo e(asset('/'.$content->options->image)); ?>" alt=" "  width="80px" class="img-responsive" /></a></td>
							<td class="invert"><?php echo e($content->name); ?></td>
							<td class="invert"><?php echo e($content->price); ?></td>
						<td class="invert">
							 <form class="" action="<?php echo e(url('/update-cart')); ?>" method="post">
								 	<?php echo csrf_field(); ?>
							 <div class="quantity">
								<div class="quantity-select">
									<!-- <div class="entry value-minus">&nbsp;</div> -->

										<input class="entry value" type="number" name="qty" value="<?php echo e($content->qty); ?>">
										<input type="hidden" name="rowId" value="<?php echo e($content->rowId); ?>">


								<button type="submit" class="item_add hvr-outline-out button2" style="margin-left: 20px; border:0; color: #fff; font-weight: 700; padding: 5px 15px;" name="button">Update</button>
									<!-- <div class="entry value-plus active">&nbsp;</div> -->
								</div>
							</div>

						</form>
						</td>

						<td class="invert">BDT <?php echo e($content->total); ?></td>
						<td class="invert-closeb">
							<div class="rem">

								<a href="<?php echo e(('/delete-cart/'.$content->rowId)); ?>">
								<div class="close1"> </div></a>
							</div>

					</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td colspan="4" style="color:#fff; background:#FDA30E; font-weight: 700;">Total :</td>
									<td >BDT <?php echo e(Cart::total()); ?></td>
								</tr>
								<!--quantity-->
									<script>
									$('.value-plus').on('click', function(){
										var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)+1;
										divUpd.text(newVal);
									});

									$('.value-minus').on('click', function(){
										var divUpd = $(this).parent().find('.value'), newVal = parseInt(divUpd.text(), 10)-1;
										if(newVal>=1) divUpd.text(newVal);
									});
									</script>
								<!--quantity-->
			</table>
		</div>


		<h3 style="margin-top:80px; font-weight:700; color :#FDA30E;">Payment From</h3>

			<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
		<?php endif; ?>
			<?php if(session('error')): ?>
    <div class="alert alert-success">
        <?php echo e(session('error')); ?>

    </div>
		<?php endif; ?>

		<div class="col-4">
		</div>
		<div class="col-4">


	<form class="" action="<?php echo e(url('/checkout/payment/save')); ?>" method="post">
		<?php echo csrf_field(); ?>
		<div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="cash">
        <input type="radio" class="form-check-input" name="payment_type" value="cash" id="cash" name="optradio" checked style="margin-right : 20px;">Cash On Delivery
      </label>
    </div>
    <div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="bkash">
        <input type="radio" class="form-check-input" name="payment_type" value="bkash" id="bkash" name="optradio" style="margin-right : 20px;">Bkash
      </label>
    </div>
    <div class="form-check " style="margin:20px 0;">
      <label class="form-check-label" for="Paypal">
        <input type="radio" class="form-check-input" name="payment_type" value="paypal" id="Paypal" style="margin-right : 20px;">Paypal
      </label>
    </div>
    <button type="submit" name="submit" class="btn btn-primary">Submit</button>

	</form>
	</div>
	<div class="col-4">

	</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontEnd.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>